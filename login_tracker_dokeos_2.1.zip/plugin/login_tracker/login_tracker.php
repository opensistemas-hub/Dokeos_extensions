<?php
$language_file = 'login_tracker';

$cidReset = true;
echo '<link rel="stylesheet" href="css/default.css" type="text/css">';
include('../../main/inc/global.inc.php');

$this_section = SECTION_PLATFORM_ADMIN;

api_protect_admin_script();

$interbreadcrumb[] = array('url' => 'index.php', 'name' => get_lang('PlatformAdmin'));

// Database Table Definitions
$tbl_settings_current = Database::get_main_table(TABLE_MAIN_SETTINGS_CURRENT);

$message = '';

require api_get_path(LIBRARY_PATH) . 'formvalidator/FormValidator.class.php';

$nameTool = 'Login stats';
Display::display_header($nameTool);

$track_e_login  = Database :: get_statistic_table(TABLE_STATISTIC_TRACK_E_LOGIN);
?>


<div id="message" style="display: none">
    <?php
    if (!empty($message))
        Display::display_normal_message($message)
        ?>
</div>

<div id="content" align="center">

    <?php
    /*  LOGINS LAST 30 DAYS */
    echo '<h3>' . get_lang('Logins_last_30_days') . '</h3>';


    $d = array();
    for ($i = 0; $i < 30; $i++)
        $d[] = date("d-m", strtotime('-' . $i . ' days'));
    $day_names = array_reverse($d);

    $day_logins = array();
    $day_users = array();

    for ($i = 0; $i < 30; $i++) {

        $day_logins[$i] = 0;
        $day_users[$i] = 0;
    }

    $sql_day = 'SELECT concat(substr(login_date, 9,2), \'-\', substr(login_date,6,2)) day, count(login_id) logins, count(distinct(login_user_id)) users
		FROM '.$track_e_login.'  
		WHERE login_date   >= CURDATE() - INTERVAL 30 DAY
		GROUP BY day
		ORDER BY login_date';

    $res = api_sql_query($sql_day);
    while ($row = mysql_fetch_array($res)) {
        for ($i = 0; $i < 30; $i++) {
            if ($day_names[$i] == $row['day']) {
                $day_logins[$i] = $row['logins'];
                $day_users[$i] = $row['users'];
            }
        }
    }
    ?>
    <table class="results">
        <tr class="header">
            <?php
            echo '<th>' . get_lang('Day') . '</th>';
            for ($i = 0; $i < 30; $i++) {
                echo '<th>' . str_replace('-', ' -',$day_names[$i]) . '</th>';
            }
            ?>
        </tr>
        <tr class="data">
            <?php
            echo '<td>' . get_lang('Number_of_logins') . '</td>';
            for ($i = 0; $i < 30; $i++) {
                echo '<td>' . $day_logins[$i] . '</td>';
            }
            ?>
        </tr>
        <tr class="data">
            <?php
            echo '<td>' . get_lang('Number_of_users') . '</td>';
            for ($i = 0; $i < 30; $i++) {
                echo '<td>' . $day_users[$i] . '</td>';
            }
            ?>
        </tr>
    </table>

    <!-- LOGINS PER MONTH -->
    <?php
    echo '<h3>' . get_lang('Logins_per_month') . '</h3>';



    $month_names = array();
    $month_logins = array();
    $month_users = array();
    for ($i = 0; $i < 12; $i++) {

        $month_names[$i] = 1 + ((date('m') + $i) % 12);

        if ($month_names[$i] < 10)
            $month_names[$i] = '0' . $month_names[$i];

        if ($month_names[$i] > date('m'))
            $month_names[$i].='-' . (date('Y') - 1);
        else
            $month_names[$i].='-' . date('Y');

        $month_logins[$i] = 0;
        $month_users[$i] = 0;
    }

    $first_month_name = date('m') . '-' . (date('Y') - 1);
    array_unshift($month_names, $first_month_name);

    $year = date('Y') - 1;
    $month = date('m');
    $start_date = $year . '-' . $month;
    $sql_month = 'SELECT concat(substr(login_date, 6,2), \'-\', substr(login_date,1,4)) month, count(login_id) logins, count(distinct(login_user_id)) users
		FROM '.$track_e_login.'  
		WHERE login_date > \'' . $start_date . '\' 
		GROUP BY month
		ORDER BY login_date';

    $res = api_sql_query($sql_month);
    while ($row = mysql_fetch_array($res)) {
        for ($i = 0; $i < 13; $i++) {
            if ($month_names[$i] == $row['month']) {
                $month_logins[$i] = $row['logins'];
                $month_users[$i] = $row['users'];
            }
        }
    }
    ?>
    <table class="results">
        <tr class="header">
            <?php
            echo '<th>' . get_lang('Month') . ': </th>';
            for ($i = 0; $i < 13; $i++) {
                echo '<th>' . $month_names[$i] . '</th>';
            }
            ?>
        </tr>
        <tr class="data">
            <?php
            echo '<td>' . get_lang('Number_of_logins') . '</td>';
            for ($i = 0; $i < 13; $i++) {
                echo '<td>' . $month_logins[$i] . '</td>';
            }
            ?>
        </tr>
        <tr class="data">
            <?php
            echo '<td>' . get_lang('Number_of_users') . '</td>';
            for ($i = 0; $i < 13; $i++) {
                echo '<td>' . $month_users[$i] . '</td>';
            }
            ?>
        </tr>
    </table>

    <!-- LOGINS PER YEAR -->
    <?php
    echo '<h3>' . get_lang('Logins_per_year') . '</h3>';
    ?>
    <table class="results">
        <thead>
            <tr class="header">
                <?php
                $logins = array();

                echo '<th>' . get_lang('Year') . ': </th>';
                $sql_year = 'SELECT substr(login_date, 1,4) year, count(login_id) logins, count(distinct(login_user_id)) users 	FROM '.$track_e_login.'    GROUP BY substr(login_date, 1,4)';
                $res = api_sql_query($sql_year);
                while ($row = mysql_fetch_array($res)) {
                    echo '<th>' . $row['year'] . '</th>';
                }
                echo '</tr></thead>';
                echo '<tbody>';
                echo '<tr class="data">';
                echo '<td>' . get_lang('Number_of_logins') . ' </td>';
                $res = api_sql_query($sql_year);
                while ($row = mysql_fetch_array($res)) {
                    echo '<td>' . $row['logins'] . '</td>';
                }
                echo '</tr><tr class="data">';
                echo '<td>' . get_lang('Number_of_users') . ' </td>';
                $res = api_sql_query($sql_year);
                while ($row = mysql_fetch_array($res)) {
                    echo '<td>' . $row['users'] . '</td>';
                }
                echo '</tr></tbody>';
                ?>
    </table>


</div><!-- /content -->


<?php
/*
  ==============================================================================
  FOOTER
  ==============================================================================
 */
Display::display_footer();
?>

