******************************** INFORMATION ***********************************
course_messages plugin for Dokeos 1.8
Author: Raul Hijosa Nieto
Email: rhijosa@opensistemas.com
Date: November 2013
Languages: English, Spanish

This plugin allows both students and administrators communicate with other users
registered in a course they are registered using a new course tool. They can send
and receive text messages and attach files into a message.

******************************** ZIP CONTENT************************************

README_COURSE_MESSAGES.txt
create_table_message.sql
main/plugin/course_messages
main/inc/lib/scriptaculous
main/inc/lib/js/dialog.js
main/img/course_messages.png
main/img/course_messages_na.png
main/lang/english/course_messages.inc.php
main/lang/spanish/course_messages.inc.php
main/lang/english/course_home.inc.php
main/lang/spanish/course_home.inc.php
main/inc/lib/add_course.lib.inc.php


******************************** INSTALLATION **********************************

	* unzip course_messages.zip file from your dokeos home directory
	  (i.e /var/www/dokeos/)

	* Run the query in the file create_table_message.sql in your database client

IMPORTANT: This will overwrite a script from the original installation of Dokeos:

		* main/inc/lib/add_course.lib.inc.php

and two language files:

		* main/lang/english/course_home.inc.php
		* main/lang/spanish/course_home.inc.php
 
If you had already modify this file then you will loose your changes.
If you don't want this to happen, you can unzip the plugin in any other diretory and then 
copy all the files uncompressed but these three.
After that, you will have to edit the file "main/inc/lib/add_course.lib.inc.php" and add a line to complete the query of the course tool table adding a new 
field.
Below the following line:
api_sql_query("INSERT INTO `" . $tbl_course_homepage . "` VALUES ('', '" . TOOL_STUDENTPUBLICATION . "','work/work.php','works.gif','".string2binary(api_get_setting('course_create_active_tools', 'student_publications')) . "','0','squaregrey.gif','NO','_self','interaction')");

insert this line:
api_sql_query("INSERT INTO `" . $tbl_course_homepage . "` VALUES ('', 'course_messages','plugin/course_messages/inbox.php','course_messages.png','1','0','squaregrey.gif','0','_self','interaction')");

