<?php

include_once ('../../../main/inc/global.inc.php');

$BANNED_EXTENSIONS = array('php', 'sh', 'bash', 'exe', 'js', 'css', 'html', 'htm', 'phtml', 'deb', 'rpm');

$BANNED_MIMES = array('text/php', 'application/x-sh', 'application/x-bash', 'application/x-shellscript', 'text/x-shellscript', 'exe', 'application/x-javascript', 'text/js', 'text/javascript', 'text/css', 'text/html', 'text/htm', 'text/phtml');

$user_id = api_get_user_id();

if (isset($_POST['accion']) && $_POST['accion'] == "Send") {
    $to_id = $_POST[user_id];
    $subject = $_POST[subject];
    $text = $_POST[text];
    $query_message_insert = 'INSERT INTO message (from_id, to_id, subject, text, created_at, course_code)';
    $query_message_insert.='values (' . $user_id . ', ' . $to_id . ', \'' . $subject . '\', \'' . $text . '\', now(),\'' . $_GET['cidReq'] . '\')';
    $rs_message_insert = mysql_query($query_message_insert);

    $message_id = mysql_insert_id();

    if (isset($_FILES['messageFile']) && count($_FILES['messageFile']) > 0 && $_FILES['messageFile']['error'] == UPLOAD_ERR_OK) {
        $tmp_name = $_FILES["messageFile"]["tmp_name"];
        $filename = $_FILES["messageFile"]["name"];

        $filemime = strtolower($_FILES["messageFile"]["type"]);
        echo '<br/>';
        $fileext = strtolower(substr($filename, 1 + strrpos($filename, '.')));

        $calculated_filemime = exec('file --brief --mime-type ' . $tmp_name);

        if (in_array($fileext, $BANNED_EXTENSIONS)) {
            header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=bannedext');
            die();
        }

        if (in_array($filemime, $BANNED_MIMES)) {
            header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=bannedmime');
            die();
        }
        if (in_array($calculated_filemime, $BANNED_MIMES)) {
            header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=bannedfile');
            die();
        }

        $courseInfo = api_get_course_info($_GET['cidReq']);

        if (empty($courseInfo)) {
            header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=course');
            die();
        }

        $finalPath_part1 = api_get_path(SYS_COURSE_PATH);

        $finalPath_part1 .= $courseInfo['path'];

        if (!is_dir($finalPath_part1) || !is_readable($finalPath_part1)) {
            header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=coursedir');
            die();
        }

        $finalPath_part2 = 'upload/message/';

        if ($_SESSION['_uid']['is_plattformAdmin']==1) {
            $finalPath_part2 .= $to_id;
        } else {
            $finalPath_part2 .= $user_id;
        }

        if (!file_exists($finalPath_part1 . '/' . $finalPath_part2)) {
            $result = mkdir($finalPath_part1 . '/' . $finalPath_part2, 0774, true);

            if (!$result) {
                header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=coursedircreate');
                die();
            }

            $result = file_put_contents($finalPath_part1 . '/upload/message/.htaccess', 'Deny All');
            if (8 != $result) {
                header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=coursedircreate');
                die();
            }
        }

        $finalPath_name = $message_id . '_' . date('ymd_His') . '.file';

        $result = move_uploaded_file($tmp_name, $finalPath_part1 . '/' . $finalPath_part2 . '/' . $finalPath_name);

        if (!$result) {
            header('Location: inbox.php?cidReq=' . $_GET['cidReq'] . '&error=filemoving');
            die();
        }

        $update_message = 'UPDATE message SET filepath=\'' . mysql_escape_string($finalPath_part2 . '/' . $finalPath_name) . '\', `filename`=\'' . mysql_escape_string($filename) . '\' WHERE id=' . $message_id . '';
        mysql_query($update_message);
    }
}


header('Location: inbox.php?cidReq=' . $_GET['cidReq']);
?>