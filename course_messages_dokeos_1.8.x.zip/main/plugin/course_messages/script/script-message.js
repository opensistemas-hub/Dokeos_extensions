// JavaScript Document

$(document).ready(function() {
	
		$('#inbox').show();				  
		$('#sent').hide();
		/*$('#recuadro-texto').hide();*/
	
	$('#bandeja_de_entrada a').click(function() {
		$('#inbox').show();				  
		$('#sent').hide();
	});	
	
	$('#bandeja_de_salida a').click(function() {
		$('#inbox').hide();				  
		$('#sent').show();
	});

	/*$('#inbox a').click(function() {
		$('#recuadro-texto').show();		
		$('#inbox').hide();				  
	});*/

   /* TABLA*/



}); //Ready
