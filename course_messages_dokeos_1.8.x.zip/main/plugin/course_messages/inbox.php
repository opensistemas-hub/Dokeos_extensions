<?php
$language_file = 'course_messages';
include_once ('../../../main/inc/global.inc.php');
echo '<script src="'.api_get_path(WEB_LIBRARY_PATH).'scriptaculous/prototype.js" type="text/javascript"></script>';
echo '<link href="css/style-message.css" rel="stylesheet" type="text/css" />';
echo '<script type="text/javascript" src="'.api_get_path(WEB_LIBRARY_PATH).'js/dialog.js"></script>';

?>
<script type="text/javascript">
function call_showDialog(){
  var formulario='';


  formulario+='<?php echo generate_form_new_message();?>';



  showDialog(formulario, "sendMessage", "void", "form_new_message", {title:"<?php echo get_lang('Send_message'); ?>",textAcceptButton:"<?php echo get_lang('Send'); ?>", textCancelButton:"<?php echo get_lang('Cancel'); ?>"} );
}

function call_showDialog_response( paramSubject, toId ){
    call_showDialog();

    $('subject').value=paramSubject;
    $('subject').disabled = 'true';


    var selectUserId = $('user_id');

    var numOptions = selectUserId.options.length;
    for( var idxOption=0; idxOption<numOptions; ++idxOption ) {
	var option = selectUserId.options[ idxOption ];
	if( option.value == toId ) {
	    option.selected = 'true';
	    }
	}

    selectUserId.disabled = 'true';

    }

function sendMessage( nombreForm ){
  $('subject').disabled = '';
  $('user_id').disabled = '';
  if( !$('showFileInput').checked ) {
    $('messageFile').value='';
    $('messageFile').disabled=true;
    }
  $('form_new_message').submit();

}
</script>

<?php

Display::display_header(get_lang('Course_message'));
function date_and_time($date_time){
  list($fecha,$hora)=explode(" ",$date_time);
  list($anio,$mes,$dia)=explode("-", $fecha);
  return(get_lang('Date').': '.$dia.'-' .$mes.'-'.$anio. ' '.get_lang('Hour').': '. $hora);
}



/*************** SHOW INBOX *************/

$user_id = api_get_user_id();
$div_new_message = '<div id="new_message_button"><a href="new_message.php?cidReq='.$_GET['cidReq'].'">'.get_lang('NEW MESSAGE').'</a></div>';
$query_select_messages_inbox='SELECT * FROM message
			INNER JOIN user ON message.from_id=user.user_id
			WHERE message.to_id='.$user_id.' AND message.course_code=\''.$_GET['cidReq'].'\' ORDER BY message.created_at DESC';


$rs_select_messages=mysql_query($query_select_messages_inbox);

$div_new_message_button='<div id="new_message_button"><a href="javascript:void(null)" onclick="call_showDialog()">'.get_lang('New_message').'</a></div>';

$div_menu='<div id="message-menu">
    <ul>
    	<li><div id="inbox"><a href="inbox.php?cidReq='.$_GET['cidReq'].'">'.get_lang('Inbox').'</a></div></li>
    	<li><div id="outbox"><a href="inbox.php?cidReq='.$_GET['cidReq'].'&inbox=2">'.get_lang('Outbox').'</a></div></li>
    </ul>
    </div>';

$div_inbox="\n".'<div id="inbox"><h3>'.get_lang('Inbox').':</h3>';
$div_inbox.= '<table>
            	<thead>
                    <tr class="heading">
                    <td class="status">'.get_lang('STATUS').':</td>
                    <td class="to"><span>'.get_lang('FROM').':</span></td>
                    <td class="subject"><span>'.get_lang('SUBJECT').':</span></td>
                    <td class="sent"><span>'.get_lang('SENT').':</span></td>
                    <td class="answer">'.get_lang('ANSWER').'</td>
                    </tr>
            	</thead>
                <tbody>';

while($row=mysql_fetch_array($rs_select_messages)){
  $message_id=$row['id'];
  $message_from_id=$row['from_id'];
  $message_from=$row['firstname'].' '.$row['lastname'];
  $message_to_id=$row['to_id'];
  $message_subject=$row['subject'];
  $message_text=$row['text'];
  $message_viewed=$row['viewed_at'];
  $message_filename=$row['filename'];
  $link='<a href="'.$_SERVER['PHP_SELF'].'?message_id='.$message_id.'&cidReq='.$_GET['cidReq'].'">';
  if ($message_viewed=='NULL' || empty($message_viewed)){
      $div_class_type='unread_message';
      $td_icono='<tr><td class="unread">'.$link.'<img src="images/unread.png" /></a></td>';
  }else{
      $div_class_type='read_message';
      $td_icono='<td class="read">'.$link.'<img src="images/read.png" /></a></td>';

  }
  $message_created_at=$row['created_at'];
  $message_course_code=$row['course_code'];

  $message_line=$link.$message_from.'</a></div></td> <td class="'.$div_class_type.'">'.$link.$message_subject.'</a></td><td class="'.$div_class_type.'"> '.$link.  date_and_time($message_created_at).'</a>';
  $div_inbox.="\n\t".$td_icono.'<td><div class="'.$div_class_type.'">';
  $div_inbox.=$message_line.'</a></div></td>';

  $encoded_message_subject=URLencode($message_subject);


  $div_inbox.='<td class="answer"><img src="images/answer.png" style="cursor:pointer;" onclick="javascript:call_showDialog_response( \''.$message_subject.'\', \''.$message_from_id.'\' )"/></td></tr>';

  if ($_GET['message_id']==$message_id){
    $div_message_text='<h3>'.get_lang('Content_of_received_message').':</h3>';
    $div_message_text.='<div class="heading" style="text-align:left; padding-left:10px;">'.$message_subject.'</div><div class="message_text">'.$message_text.'</div>';

    if( !empty( $message_filename ) ) {
      $div_message_text.='<div style="margin-top:2em;">'.get_lang('Attached_file').':&nbsp;&nbsp;&nbsp;<a href="./download_attachment.php?message_id='.$message_id.'&cidReq='.$_GET['cidReq'].'" style="font-family:monospace; text-decoration:underline;">'.$message_filename.'</a></div>';
      }

      $div_message_text.='<input type="button" value="'.get_lang('Answer').'" style="margin-top:2em;" onclick="javascript:call_showDialog_response( \''.$message_subject.'\', \''.$message_from_id.'\' )"/>';

    $query_update_viewed='UPDATE message set viewed_at=now() WHERE id='.$message_id.' AND viewed_at is NULL';
    $rs_query_update_viewed=mysql_query($query_update_viewed);
  }
}
$div_inbox.='</tbody></table></div>';


/************** SHOW SENT MESSAGES ***************/

$query_select_messages_sent='SELECT * FROM message
			INNER JOIN user ON message.to_id=user.user_id
			WHERE message.from_id='.$user_id.' AND message.course_code=\''.$_GET['cidReq'].'\' ORDER BY message.created_at';

$rs_select_messages=mysql_query($query_select_messages_sent);

$div_sent="\n".'<div id="sent"><h3>'.get_lang('Sent_messages').':</h3>';
$div_sent.= '<table>
            	<thead>
                    <tr class="heading">
                    <td class="to"><span>'.get_lang('TO').':</span></td>
                    <td class="subject"><span>'.get_lang('SUBJECT').':</span></td>
                    <td class="sent"><span>'.get_lang('SENT').':</span></td>
                    </tr>
            	</thead>
                <tbody>';

while($row=mysql_fetch_array($rs_select_messages)){
  $message_id=$row['id'];
  $message_to=$row['firstname'].' '.$row['lastname'];
  $message_from_id=$row['from_id'];
  $message_subject=$row['subject'];
  $message_text=$row['text'];
  $message_viewed=$row['viewed'];
  $message_created_at=$row['created_at'];
  $message_course_code=$row['course_code'];
  $message_filename=$row['filename'];

  $link='<a href="'.$_SERVER['PHP_SELF'].'?message_id='.$message_id.'&cidReq='.$_GET['cidReq'].'">';
  $message_line='<tr><td>'.$link.$message_to.'</a></td><td>'.$link.$message_subject.'</a></td><td> '.$link.date_and_time($message_created_at);
  $div_sent.=$message_line.'</a></td></tr>';
  if ($_GET['message_id']==$message_id){

    $div_message_text='<h3>'.get_lang('Content_of_sent_message').':</h3>';
    $div_message_text.='<div class="heading" style="text-align:left; padding-left:10px;">'.$message_subject.'</div><div class="message_text">'.$message_text.'</div>';

    if( !empty( $message_filename ) ) {
      $div_message_text.='<div style="margin-top:2em;">'.get_lang('Attached_file').':&nbsp;&nbsp;&nbsp;<a href="./download_attachment.php?message_id='.$message_id.'&cidReq='.$_GET['cidReq'].'" style="font-family:monospace; text-decoration:underline;">'.$message_filename.'</a></div>';
      }
  }

}

$div_sent.='</tbody></table></div>';
echo '<div id="container">';
echo $div_new_message_button;
echo '<br>';
echo '<br>';
echo ($div_menu);
echo '<div id="wrapper">';
if (!isset($_GET['message_id'])){
    if (!$_GET['inbox']==2){
	echo ($div_inbox);
    }else{
	echo ($div_sent);
    }
}else{
    echo ($div_message_text);
}
echo '</div>';
echo '</div>';
echo '<div id="mydialog" style="display:none"></div>';
Display::display_footer();


/* Returns the status of the actual user for the actual course */
function my_status(){
    $user_id = api_get_user_id();
    $query_status='SELECT status FROM course_rel_user WHERE course_code=\''.$_GET['cidReq'].'\' AND user_id='.$user_id.' LIMIT 1';
    $rs_status=mysql_query($query_status);
    if ($row=mysql_fetch_assoc($rs_status)){
	return $row['status'];
    }
    return 0;
}

/* Returns an array with the list of users (user_id, complete_name) that the actual user can send a mesage to */
function possible_destiny_list(){
    $user_id = api_get_user_id();
	$query_select_destiny='SELECT user.user_id user, user.firstname fn, user.lastname ln';
	$query_select_destiny.=' FROM user JOIN course_rel_user ON user.user_id=course_rel_user.user_id';
	$query_select_destiny.=' WHERE course_rel_user.course_code=\''.$_GET['cidReq'].'\' AND user.user_id!='.$_SESSION['_user']['user_id'];
	$query_select_destiny.=' ORDER BY user.lastname';
    file_put_contents("/tmp/debug_message", $query_select_destiny, FILE_APPEND);
    $rs_select_destiny=mysql_query($query_select_destiny);
    $i=0;
    while($row=mysql_fetch_array($rs_select_destiny)){
	$destiny[$i]['user_id']=$row['user'];
	$destiny[$i]['name']=$row['fn'].' '.$row['ln'];
	$i++;
    }
    return($destiny);
}

function return_bytes($val) {
    $val = trim($val);
    $last = strtolower($val[strlen($val)-1]);
    switch($last) {
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }

    return $val;
}

function generate_form_new_message(){

$user_id = api_get_user_id();

if (isset( $_GET['subject'] )){
    $inputs='<div id="answer"><INPUT NAME="user_id" SIZE="20" MAXLENGTH="11" TYPE="HIDDEN" VALUE="'.$_GET['to_id'].'" readonly/><br><br>';
    $inputs.='&nbsp;&nbsp;&nbsp;&nbsp;'.get_lang('Subject').': ';
    $inputs.='<INPUT NAME="subject" SIZE="30" MAXLENGTH="50" TYPE="TEXT" VALUE="'.$_GET['subject'].'" readonly/><br><br></div>';
}else{
    $destiny=possible_destiny_list();
    $inputs='<div id="newmsg">'.get_lang('To').':';
    $inputs.='      <SELECT NAME="user_id" id="user_id" SIZE="1">';
    for ($i=0; $i<count($destiny);$i++){
	  $inputs.='<OPTION VALUE="'.$destiny[$i]['user_id'].'">'.$destiny[$i]['name'].'</OPTION>';
    }
    $inputs.='</SELECT>';

    $inputs.='&nbsp;&nbsp;&nbsp;&nbsp'.get_lang('Subject').': ';
    $inputs.='<INPUT NAME="subject" id="subject" SIZE="30" MAXLENGTH="50" TYPE="TEXT" ><br><br></div>';
    $inputs.='<INPUT NAME="accion" TYPE="hidden" VALUE="Send">';
}


  $htmlForm .= '<form id="form_new_message" ACTION="new_message.php?cidReq='.$_GET['cidReq'].'" method="POST" enctype="multipart/form-data">';
  $htmlForm .= '<br>';
  $htmlForm .= '<br>';

  $htmlForm .= $inputs;

  $htmlForm .= get_lang('Text').':<br>';
  $htmlForm .= '<TEXTAREA COLS=60 ROWS=15 NAME="text"></TEXTAREA>';
  $htmlForm .= '<br>';
  $htmlForm .= '<br>';

  $htmlForm .= '<input id="showFileInput" name="showFileInput" type="checkbox" onclick="javascript:if(this.checked) {document.getElementById(\\\'boxFileInput\\\').style.display=\\\'block\\\';} else {document.getElementById(\\\'boxFileInput\\\').style.display=\\\'none\\\';}"> <label for="showFileInput">'.get_lang('Attach_a_file').'</label> <br/>';

  $htmlForm .= '<div id="boxFileInput" style="display:none; margin-top:5px;">';
  $htmlForm .= '<input id="MAX_FILE_SIZE" name="MAX_FILE_SIZE" type="hidden" value="'.return_bytes(ini_get('upload_max_filesize')).'">';
  $htmlForm .= get_lang('Select_file').': <input id="messageFile" name="messageFile" type="file"><br/>';
  $htmlForm .= get_lang('Maximum_file_size').': '.ini_get('upload_max_filesize');    //  .round( (0+ini_get('upload_max_filesize'))/1024/1024, 0 ).' Mb.';
  $htmlForm .= '</div>';

  $htmlForm .= '<div style="clear:both; height:10px;"></div>';

  $htmlForm .= '</form>';

return $htmlForm;


}
?>
