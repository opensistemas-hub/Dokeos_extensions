<?php
include_once ('../../../main/inc/global.inc.php');

  $user_id = api_get_user_id();

  $searchMessage = 'SELECT filename, filepath FROM message WHERE id='.$_GET['message_id'].' AND (from_id='.$user_id.' OR to_id='.$user_id.') LIMIT 1';

  $rsMessage = mysql_query( $searchMessage );
  $rowMessage = mysql_fetch_array( $rsMessage, MYSQL_ASSOC );

  $courseInfo = api_get_course_info( $_GET['cidReq'] );

  $fileExt = strtolower( substr( $rowMessage['filename'], 1+strrpos( $rowMessage['filename'], '.' ) ) );


  $filePath = api_get_path( SYS_COURSE_PATH ).$courseInfo['path'].'/'.$rowMessage['filepath'];
  $fileName = $rowMessage['filename'];
  if( 'csv' == $fileExt ) {
    $fileMime = 'x-application/csv';
    }
  else if( 'txt' == $fileExt ) {
    $fileMime = 'text/plain';
    }
  else {
    $fileMime = exec('file --brief --mime-type '.$filepath);
    }

   


  header( 'Content-type: '.$fileMime );


  header( 'Content-Disposition: attachment; filename="'.$fileName.'"' );


  readfile( $filePath );

?>