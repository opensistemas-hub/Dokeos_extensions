<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Show";
$langDeactivate = "Hide";
$langInLnk  = "Hidden tools and links";
$langDelLk = "Do you really want to delete this link?";
$langEnter  = "Enter";
$langCourseCreate  = "Create a course website";
$langNameOfTheLink  = "Name of the link";
$lang_main_categories_list                  = "Main category list";
$langCourseAdminOnly = "Teachers only";
$PlatformAdminOnly = "Platform Administrators only";
$langCombinedCourse = "Combined course";
$ToolIsNowVisible = "The tool is now visible.";
$ToolIsNowHidden = "The tool is now invisible.";
$EditLink = "Edit link";
$Blog_management = "Blogs management";
$Forum = "Forums";
$Course_maintenance = "Course Maintenance";
$TOOL_SURVEY = "Surveys";
$GreyIcons = "Toolbox";
$Interaction = "Interaction";
$Authoring = "Authoring";
$Administration = "Administration";
$IntroductionTextUpdated = "The introduction text has been updated";
$IntroductionTextDeleted = "Introduction text deleted";
$Course_messages = "Course messages";
?>