<?php
    $Course_message = 'Course messages';
    $Inbox = 'Inbox';
    $Outbox = 'Outbox';
    $New_message = 'New message';
    $STATUS = 'STATUS';
    $FROM = 'FROM';
    $TO = 'TO';
    $To = 'To';
    $SUBJECT = 'SUBJECT';
    $Subject = 'Subject';
    $Text = 'Text';
    $SENT = 'SENT';
    $ANSWER = 'ANSWER';
    $Answer = 'Answer';
    $Hour = 'Hour';    
    $Sent_messages = 'Sent messages';
    $Attached_file = 'Attached file';
    $Content_of_sent_message = 'Content of sent message';
    $Content_of_received_message = 'Content of received message';  
    $Select_file = 'Select file';
    $Maximum_file_size = 'Maximum file size';
    $Send_message = 'Send message';
    $Attach_a_file = 'Attach a file';
?>
