<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Activar";
$langDeactivate = "Desactivar";
$langInLnk  = "Enlaces desactivados";
$langDelLk = "� Est� seguro de querer desactivar esta herramienta ?";
$langEnter  = "Entrar";
$langCourseCreate  = "Crear un curso";
$langNameOfTheLink  = "Nombre del enlace";
$lang_main_categories_list                  = "Lista de categor�as principales";
$langCourseAdminOnly = "S�lo profesores";
$PlatformAdminOnly = "S�lo administradores de la plataforma";
$langCombinedCourse = "Curso combinado";
$ToolIsNowVisible = "Ahora la herramienta es visible";
$ToolIsNowHidden = "Ahora la herramienta no es visible";
$EditLink = "Editar enlace";
$Blog_management = "Gestion de blogs";
$Forum = "Foros";
$Course_maintenance = "Mantenimiento del curso";
$TOOL_SURVEY = "Encuestas";
$GreyIcons = "Caja de herramientas";
$Interaction = "Interacci�n";
$Authoring = "Creaci�n de contenidos";
$Administration = "Administraci�n";
$IntroductionTextUpdated = "El texto de introducci�n ha sido actualizado";
$IntroductionTextDeleted = "Texto de introducci�n eliminado";
$Course_messages = "Mensajes de curso";
?>