<?php
    $Course_message = 'Mesajes de curso';
    $Inbox = 'Bandeja de entrada';
    $Outbox = 'Bandeja de enviados';
    $New_message = 'Nuevo mensaje';
    $STATUS = 'ESTADO';
    $FROM = 'DE';
    $TO = 'PARA';
    $To = 'Para';
    $SUBJECT = 'ASUNTO';
    $Subject = 'Asunto';
    $Text = 'Texto';
    $SENT = 'ENVIADO';
    $ANSWER = 'RESPONDER';
    $Answer = 'Responder';
    $Hour = 'Hora';
    $Sent_messages = 'Mensajes enviados';
    $Attached_file = 'Fichero adjunto';    
    $Content_of_sent_message = 'Contenido del mensaje enviado';
    $Content_of_received_message = 'Contenido del mensaje recibido';  
    $Select_file = 'Seleccione archivo';
    $Maximum_file_size = 'Tama�o m�ximo de archivo';
    $Send_message = 'Enviar mensaje';
    $Attach_a_file = 'Adjuntar un archivo';    
?>
