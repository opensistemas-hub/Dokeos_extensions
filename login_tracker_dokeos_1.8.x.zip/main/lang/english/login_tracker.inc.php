<?php
$Logins_last_30_days = "Last 30 days logins";
$Number_of_logins = "Number of logins";
$Number_of_users = "Number of users";
$Logins_per_month = "Logins per month (last 12 and current)";
$Logins_per_year ="Logins per year";
$Login_tracker = "Login Tracker";
?>
