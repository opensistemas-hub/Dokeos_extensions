<?php
$Day = "D�a";
$Month = "Mes";
$Year = "A�o";
$Logins_last_30_days = "Conexiones en los �ltimos 30 d�as";
$Number_of_logins = "N�mero de conexiones";
$Number_of_users = "N�mero de ususarios";
$Logins_per_month = "Conexiones por mes (�ltimos 12 meses y actual)";
$Logins_per_year ="Conexiones por a�o";
$Login_tracker = "Datos de conexiones";
?>
