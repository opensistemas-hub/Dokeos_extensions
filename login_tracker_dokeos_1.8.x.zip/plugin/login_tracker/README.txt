******************************** INFORMATION ***********************************
login_tracker plugin for Dokeos 1.8.x
Author: Raul Hijosa Nieto
Email: rhijosa@opensistemas.com
Date: September 2013
Languages: English, Spanish

This plugin shows the following info to administrators:

Logins and users in the last 30 days
Logins and users in the last 12 months and current
Logins and users per year (since installation year)

******************************** ZIP CONTENT************************************

plugin/login_tracker/README.txt
plugin/login_tracker/login_tracker.php
plugin/login_tracker/css/default.css
main/lang/english/login_tracker.inc.php
main/lang/spanish/login_tracker.inc.php
main/admin/index.php

******************************** INSTALLATION **********************************

unzip login_tracker.zip file from your dokeos home directory
(i.e /var/www/dokeos/)

IMPORTANT: This will overwrite your adminisration home page script (main/admin/index.php)
If you don't want this to happen, you can unzip the plugin in any other diretory and then 
copy all the files uncompressed but main/admin/index.php manually
Additionally you will have to insert a link to the plugin(../../plugin/login_tracker/login_tracker.php )
in your main/admin/index.php script

